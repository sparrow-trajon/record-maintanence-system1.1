package com.trajon.sparrow.exceptions;

public class EmptyList extends Exception{

	
	private static final long serialVersionUID = 1L;

		public EmptyList(String message) {
		super(message);
		}
}